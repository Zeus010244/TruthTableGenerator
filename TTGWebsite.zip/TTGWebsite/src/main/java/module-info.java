module com.example.ttgwebsite {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.ttgwebsite to javafx.fxml;
    exports com.example.ttgwebsite;
}