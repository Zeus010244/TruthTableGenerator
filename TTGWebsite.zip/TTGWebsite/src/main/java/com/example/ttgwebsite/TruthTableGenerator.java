package com.example.ttgwebsite;

import java.util.*;
public class TruthTableGenerator {
    boolean output[];
    HashMap<String,Boolean> input = new HashMap<>();
    String expression;
    public TruthTableGenerator(String exp){
        expression = exp;
        for(int i = 0 ; i<expression.length() ; i++){ // Iterating through the expression and adding the variables to the hashmap
            if(Character.isLetter(exp.charAt(i))){
                String token = "";
                while(i<expression.length() && Character.isLetter(exp.charAt(i))){
                    token += exp.charAt(i);
                    ++i;
                }
                if(!input.containsKey(token)){
                    input.putIfAbsent(token,false);
                }
            }
        }
        output = new boolean[(int)Math.pow(2, input.size())];   //Generating the output column as per the number of variables present
        TreeMap<String,Boolean> treeMap = new TreeMap<>(input); //Sorting The Map Using A TreeMap So All Terms Are Placed In Alphabetical Order.
        input.clear();
        input.putAll(treeMap);
        treeMap.clear();
    }
    String[] expressionGenerator(){
        int size = 0 ,i =0 ;
        while(i<expression.length()){ // finding the number of terms to separate, so we can create the expression array.
            char curr = expression.charAt(i);
            if(!Character.isLetter(curr)){
                switch(curr){
                    case ' ':
                        i++;
                        break;
                    case '.', '+','\'','(',')','@':
                        size++;
                        i++;
                        continue;
                    case '-':
                        size++;
                        i+=2;
                        continue;
                    case '<':
                        size++;
                        i+=3;
                        continue;
                }
            }
            while(i<expression.length() && Character.isLetter(expression.charAt(i))){
                ++i;
            }
            ++size;
        }
        String exp[] = new String[size];
        size = 0;
        for(i = 0; i<expression.length() ; ++i){
            if(i<expression.length() && !Character.isLetter(expression.charAt(i))){
                switch(expression.charAt(i)){
                    case '.', '+','\'','(',')','@':
                        exp[size++] = ""+expression.charAt(i);
                        continue;
                    case '-':
                        exp[size++] = ">";
                        i+=1;
                        continue;
                    case '<':
                        exp[size++] = "<";
                        i+=2;
                        continue;
                }
            }
            String curr = "";
            int j = i;
            for(; j<expression.length() && Character.isLetter(expression.charAt(j)); j++){
                curr += expression.charAt(j);
            }
            exp[size++] = curr;
            i=j-1;
        }
        return exp;
    }
    char[] expressionFiller(String exp[]){
        char currExp[] = new char[exp.length];
        for(int i = 0 ; i<exp.length ; i++){
            if(input.containsKey(exp[i])){
               currExp[i] = input.get(exp[i])?'1':'0';
               continue;
            }
            currExp[i] = exp[i].charAt(0);
        }
        return currExp;
    }
    void hashMapValueUpdater(){
        int[] binaryNum = new int[input.size()];
        int ctr = 0;
        for (Map.Entry<String,Boolean> mapElement : input.entrySet()){
            int curr = mapElement.getValue() ? 1 : 0;
            binaryNum[ctr++] = curr;
        }
        int carry = 1;
        for(int i = input.size()-1 ; i>=0  && carry==1 ; i--){
           binaryNum[i] = (binaryNum[i] + carry)%2;
           carry = binaryNum[i]==0 ? 1 : 0;
        }
        ctr =0;
        for (Map.Entry<String,Boolean> mapElement : input.entrySet()){
            int curr = mapElement.setValue(binaryNum[ctr++]==1) ? 1 : 0;
        }
    }
    void TableGenerator(){
        String exp[] = expressionGenerator();
        for(int i = 0 ; i < output.length ; i++) {
            char currExp[] = expressionFiller(exp);
            ShuntingYardAlgo obj2 = new ShuntingYardAlgo(currExp);
            obj2.InfixToPostfix();
            output[i] = obj2.solver();
            hashMapValueUpdater();
        }
    }
    String[] MintermMaxtermGenerator(){
        String[] vars = new String[input.size()]; int index = 0;
        for (Map.Entry<String,Boolean> mapElement : input.entrySet()){
            vars[index++] = mapElement.getKey();
        }
        String canonicalSOPExp = "Σ(";
        String mintermSOPExp = "";
        String canonicalPOSExp = "π(";
        String maxtermPOSExp = "";
        for(int i = 0 ; i< output.length ; i++){
            if(output[i]){
                canonicalSOPExp += " "+(""+i)+" ,";
                String binaryNum = Integer.toBinaryString(i) , currMinterm = "";
                index = 0; int diffBetweenNumAndVar = vars.length - binaryNum.length() , binCtr =0;
                while(diffBetweenNumAndVar-->0){ // Since the binaryNum will not contain the preceding 0s we have to manually input them till the current binary number
                    vars[index++] = "0";
                }
                for( ; index<vars.length  ; index++ , binCtr++){ // filling in the current binary number
                    vars[index] = ""+binaryNum.charAt(binCtr);
                }
                index = 0;
                for (Map.Entry<String,Boolean> mapElement : input.entrySet()){
                   if(vars[index++].equals("1"))  mintermSOPExp += (mapElement.getKey()+".");
                   else                           mintermSOPExp += (mapElement.getKey()+"'.");
                }
                mintermSOPExp = mintermSOPExp.substring(0,mintermSOPExp.length()-1); // Removing the last unnecessary and operator
                mintermSOPExp += " + ";
            }
            else{
                canonicalPOSExp += " "+(""+i)+" ,";
                String binaryNum = Integer.toBinaryString(i) , currMaxterm = "";
                index = 0; int diffBetweenNumAndVar = vars.length - binaryNum.length() , binCtr =0;
                while(diffBetweenNumAndVar-->0){                                 // Since the binaryNum will not contain the preceding 0s we have to manually input them till the current binary number
                    vars[index++] = "0";
                }
                for( ; index<vars.length  ; index++ , binCtr++){                 // filling in the current binary number
                    vars[index] = ""+binaryNum.charAt(binCtr);
                }
                index = 0;
                for (Map.Entry<String,Boolean> mapElement : input.entrySet()){
                    if(vars[index].equals("0") && 1==vars.length)          maxtermPOSExp += ("( "+mapElement.getKey()+" )");
                    else if(vars[index].equals("1") && 1==vars.length)     maxtermPOSExp += ("( "+mapElement.getKey()+"' )");
                    else if(vars[index].equals("0") && index==0)                 maxtermPOSExp += ("( "+mapElement.getKey()+" + ");
                    else if (vars[index].equals("0") && index == input.size()-1) maxtermPOSExp += (mapElement.getKey()+")");
                    else if (vars[index].equals("0"))                            maxtermPOSExp += (mapElement.getKey()+" + ");
                    else if (index==0)                                           maxtermPOSExp += ("( "+mapElement.getKey()+"' + ");
                    else if(index==input.size()-1)                               maxtermPOSExp += (mapElement.getKey()+"')");
                    else                                                         maxtermPOSExp += (mapElement.getKey()+"' + ");
                    ++index;
                }
                maxtermPOSExp += " . ";
            }
        }
        canonicalSOPExp = canonicalSOPExp.lastIndexOf(',') == -1 ? canonicalSOPExp : canonicalSOPExp.substring(0,canonicalSOPExp.length()-1);
        mintermSOPExp   = mintermSOPExp.lastIndexOf('+') == -1 ? mintermSOPExp : mintermSOPExp.substring(0,mintermSOPExp.length()-2);
        canonicalPOSExp = canonicalPOSExp.lastIndexOf(',') == -1 ? canonicalPOSExp : canonicalPOSExp.substring(0,canonicalPOSExp.length()-1);
        maxtermPOSExp   = maxtermPOSExp.lastIndexOf('.') == -1 ? maxtermPOSExp : maxtermPOSExp.substring(0,maxtermPOSExp.length()-2);
        return new String[]{canonicalSOPExp,mintermSOPExp,canonicalPOSExp,maxtermPOSExp};
    }
}