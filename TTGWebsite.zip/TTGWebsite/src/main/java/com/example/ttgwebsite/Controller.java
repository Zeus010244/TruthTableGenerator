package com.example.ttgwebsite;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.MapValueFactory;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.util.Duration;

import java.util.*;

public class Controller {
    String variables[];
    String exp;
    int minterms[];
    @FXML
    private VBox outputVBox;
    @FXML
    private TextField mintermInput, expInput, variableInput;
    @FXML
    private Button InfoButton;
    @FXML
    private Text mintermError, variableError;
    @FXML
    private TextArea canonicalSOP, canonicalPOS, mintermExp, maxtermExp, simplifiedExpression;
    @FXML
    private TextFlow expError;
    @FXML
    private Rectangle backgroundRectangle;
    @FXML
    private TableView<Map<String, String>> truthTable;

    public Controller() {
        variables = new String[]{};
        minterms = new int[0];
        exp = "";
    }

    private void generateMinimizedExpression() {
        simplifiedExpression.setText("");
        if (minterms.length == 0) {
            simplifiedExpression.setText("The Most Simplified Expression Is: 0");
        } else {
            QuineMcCluskeyAlgo caller = new QuineMcCluskeyAlgo(minterms, variables.length);
            String ans = caller.generateImplicantTable(minterms);
            boolean isTrue = true;
            StringTokenizer replacingBinaryWithVariables = new StringTokenizer(ans);
            ans = "";
            while (replacingBinaryWithVariables.hasMoreTokens()) {
                String currToken = replacingBinaryWithVariables.nextToken();
                for (int i = 0; i < currToken.length(); i++) {
                    char currentChar = currToken.charAt(i);
                    if (currentChar == '1') {
                        ans += variables[i];
                        isTrue = false;
                    } else if (currentChar == '0') {
                        ans += variables[i] + "'";
                        isTrue = false;
                    }
                }
                ans += " + ";
            }
            if (isTrue) simplifiedExpression.setText("The Most Simplified Expression Is: 1");
            else
                simplifiedExpression.setText("The Most Simplified Expression Is: " + ans.substring(0, ans.lastIndexOf('+')));
        }
    }

    private String processMintermInput(String input) {
        StringTokenizer mintermExtractor = new StringTokenizer(input, ", ");
        minterms = new int[mintermExtractor.countTokens()];
        if (minterms.length == 0) return "";
        int indexer = 0;
        long currMinterm = 0;
        while (mintermExtractor.hasMoreTokens()) {
            try {
                currMinterm = Long.parseLong(mintermExtractor.nextToken());
                if (currMinterm > 2147483647 || currMinterm < 0)
                    return "Minterms Must Be In The Range 0<=X<=2147483647";
                minterms[indexer++] = (int) currMinterm;
            } catch (NumberFormatException e) {
                return "The Minterms Must Not Include Letters";
            }
        }
        return "";
    }

    @FXML
    private void getMintermInput() {
        mintermError.setVisible(false);
        String input = mintermInput.getText(), error = processMintermInput(input);
        mintermError.setText(error);
        mintermError.setVisible(true);
        int maxMinterm = 0;
        for (int i = 0; i < minterms.length; i++) {
            maxMinterm = Math.max(minterms[i], maxMinterm);
        }
        if (variables.length == 0 || maxMinterm >= Math.pow(2, variables.length)) {
            variableError.setText("Insufficient Number Of Variables For The Minterms");
            variableError.setVisible(true);
            return;
        }
        generateMinimizedExpression();
    }

    private String processVariableInput(String input) {
        StringTokenizer varExtractor = new StringTokenizer(input, " ,");
        int index = 0;
        variables = new String[varExtractor.countTokens()];
        if (variables.length == 0) return "";
        Set<String> duplicateChecker = new HashSet<>();
        while (varExtractor.hasMoreTokens()) {
            String currVar = varExtractor.nextToken();
            for (int i = 0; i < currVar.length(); i++) {
                if (!Character.isLetter(currVar.charAt(i)))
                    return "Don't Use Numbers Or Special Characters In The Variables";
            }
            duplicateChecker.add(currVar);
        }
        for (String curr : duplicateChecker) variables[index++] = curr;
        return "";
    }

    @FXML
    private void getVariableInput() {
        variableError.setVisible(false);
        String input = variableInput.getText();
        String control = processVariableInput(input);
        variableError.setText(control);
        variableError.setVisible(true);
        int maxMinterm = 0;
        for (int i = 0; i < minterms.length; i++) {
            maxMinterm = Math.max(minterms[i], maxMinterm);
        }
        if (maxMinterm >= Math.pow(2, variables.length)) {
            variableError.setText("Insufficient Number Of Variables For The Minterms");
            return;
        }
        generateMinimizedExpression();
    }

    private void setError(String inp, int errorIndex) {
        expError.getChildren().clear();
        Text prev = new Text(inp.substring(0, errorIndex));
        Text error = new Text("" + inp.charAt(errorIndex));
        Text next = new Text(inp.substring(errorIndex + 1));
        String errorMsgSetter = (inp.charAt(errorIndex) == ')') ? ("Bracket Imbalance At Index: " + errorIndex + "\n") : ("Error At Index: " + errorIndex + "\n");
        Text errorMsg = new Text(errorMsgSetter);
        errorMsg.setFill(Color.RED);
        errorMsg.setFont(new Font("Montserrat", 20));
        prev.setFont(new Font("Montserrat", 20));
        prev.setFill(Color.WHITESMOKE);
        error.setFont(new Font("Montserrat", 20));
        error.setFill(Color.RED);
        next.setFont(new Font("Montserrat", 20));
        next.setFill(Color.WHITESMOKE);
        expError.getChildren().addAll(errorMsg, prev, error, next);
    }

    private void setError(String inp) {
        expError.getChildren().clear();
        Text error = new Text(inp);
        error.setFont(new Font("Helvetica", 18));
        error.setFill(Color.RED);
        expError.getChildren().add(error);
    }

    private String isValidExpression(String exp) {
        expError.getChildren().clear();
        if (exp.isEmpty()) {
            setError("Expression can't be empty");
            return "0";
        }
        Stack<Character> ParenthesesChecker = new Stack<>();
        char prev = 0;
        boolean isAlphabetPresent = false;
        for (int i = 0; i < exp.length(); i++) {
            char c = exp.charAt(i);
            if (!Character.isLetter(c)) {
                switch (c) {
                    case '-': {
                        if (prev == '<') break;
                        if ((i == 0 || i > exp.length() - 3) || (exp.charAt(i + 1) != '>') || (!Character.isLetter(prev) && prev != '\'' && prev != ')') || (!Character.isLetter(exp.charAt(i + 2)) && exp.charAt(i + 2) != '(')) {
                            setError(exp, i);
                            return "0";
                        }
                        break;
                    }
                    case '<': {
                        if ((i == 0 || i > exp.length() - 4) || (exp.charAt(i + 2) != '>' && exp.charAt(i + 1) != '-') || (!Character.isLetter(prev) && prev != '\'' && prev != ')') || (!Character.isLetter(exp.charAt(i + 3)) && exp.charAt(i + 3) != '(')) {
                            setError(exp, i);
                            return "0";
                        }
                        break;
                    }
                    case '\'': {
                        if (i == 0 || (!Character.isLetter(prev) && prev != ')')) {
                            setError(exp, i);
                            return "0";
                        }
                        break;
                    }
                    case '+', '.', '@': {
                        if ((i == 0 || i == exp.length() - 1) || ((!Character.isLetter(exp.charAt(i + 1)) && exp.charAt(i + 1) != '(') || (!Character.isLetter(prev) && prev != '\'' && prev != ')'))) {
                            setError(exp, i);
                            return "0";
                        }
                        break;
                    }
                    case '(': {
                        if (i != 0 && (Character.isLetter(prev) || prev == ')')) {
                            setError(exp, i);
                            return "0";
                        }
                        ParenthesesChecker.push(')');
                        break;
                    }
                    case ')': {
                        if (ParenthesesChecker.isEmpty()) {
                            setError(exp, i);
                            return "0";
                        }
                        ParenthesesChecker.pop();
                        break;
                    }
                    default:
                        if (c != '>') {
                            setError(exp, i);
                            return "0";
                        }
                }
            } else {
                isAlphabetPresent = true;
            }
            prev = c;
        }
        if (!ParenthesesChecker.isEmpty()) {
            setError("Uneven Or Incorrectly Placed Brackets");
            return "0";
        } else if (!isAlphabetPresent) {
            setError("No Variables Detected");
            return "0";
        }
        return "";
    }

    private void displayMintermAndMaxterms(TruthTableGenerator obj) {
        String[] expressions = obj.MintermMaxtermGenerator();
        canonicalSOP.setText(expressions[0] + ")");
        mintermExp.setText("Expression's Minterm Form: " + expressions[1]);
        canonicalPOS.setText(expressions[2] + ")");
        if (!obj.output[0] && obj.output[1] && obj.input.size() == 1) {
            for (Map.Entry<String, Boolean> curr : obj.input.entrySet())
                maxtermExp.setText("Expression's Maxterm Form: " + curr.getKey());
        } else maxtermExp.setText("Expression's Maxterm Form: " + expressions[3]);
    }

    String intToBin(int num, int numOfVariables) {
        String bin = Integer.toBinaryString(num);
        while (bin.length() < numOfVariables) {
            bin = "0" + bin;
        }
        return bin;
    }

    private void generateTruthTable() {
        TruthTableGenerator obj = new TruthTableGenerator(exp);
        obj.TableGenerator();
        String[] vars = new String[obj.input.size()];
        int indexer = 0;
        for (Map.Entry<String, Boolean> curr : obj.input.entrySet()) vars[indexer++] = curr.getKey();
        for (String curr : vars) { // Adding The Input Output Column
            TableColumn<Map<String, String>, Object> column = new TableColumn<>(curr);
            MapValueFactory map = new MapValueFactory<>(curr);
            column.setCellValueFactory(map);
            column.setPrefWidth(40);
            column.setReorderable(false);
            truthTable.getColumns().add(column);
        }
        TableColumn<Map<String, String>, Object> column = new TableColumn<>(exp); // Adding The Expression Output Column
        MapValueFactory map = new MapValueFactory<>(exp);
        column.setCellValueFactory(map);
        column.setReorderable(false);
        truthTable.getColumns().add(column);
        ObservableList<Map<String, String>> data = FXCollections.observableArrayList();
        for (int i = 0; i < obj.output.length; i++) {
            Map<String, String> row = new HashMap<>();
            String binary = intToBin(i, obj.input.size());
            int index = 0;
            for (String input : vars) {
                row.put(input, "" + binary.charAt(index++));
            }
            row.put(exp, obj.output[i] ? "1" : "0");
            data.add(row);
            truthTable.setItems(data);
        }


        displayMintermAndMaxterms(obj);
    }

    @FXML
    private void getExpInput() {
        expError.setVisible(false);
        String input = expInput.getText();
        String spaceRemover = "";
        for (int i = 0; i < input.length(); i++) {
            if (!Character.isWhitespace(input.charAt(i))) spaceRemover += input.charAt(i);
        }
        input = spaceRemover;
        String control = isValidExpression(input);
        expError.setVisible(true);
        truthTable.getColumns().clear();
        truthTable.getItems().clear();
        if (control.equals("")) {
            exp = input;
            generateTruthTable();
        }

    }

    public void initialize() {
        Tooltip tooltip = new Tooltip();
        tooltip.setText("\t\t\nRules:\nUse '.' for AND\nUse '+' For OR\nUse '@' For XOR\nUse ' ' ' i.e. ,an apostrophe, after the term for NEGATION\nUse \"->\" for IMPLICATION\nUse \"<->\" for BI-CONDITIONAL IMPLICATION\nUse '(' and ')' for PARENTHESES\nEnter The Variables & Minterms Of Your Expression In Their\nEnter Your Minterms And Variables Into Their Fields To\nGenerate Your Most Simplified Expression \nRespective Fields, To Generate The Most Simplified Expression\nFor Your Expression");
        InfoButton.setTooltip(tooltip);
        tooltip.setShowDelay(Duration.millis(10));
        tooltip.setHideDelay(Duration.millis(2000));
    }
}